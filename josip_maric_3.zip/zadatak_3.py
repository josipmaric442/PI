import bisect

class MultiSkup(object):
    def __init__(self, rjecnik = None):
        self.__kljucevi = []
        self.__rjecnik = {}

        if rjecnik is not None:
            if isinstance(rjecnik, MultiSkup):
                self.__rjecnik = rjecnik.__rjecnik.copy()
                self.__kljucevi = list(rjecnik.__kljucevi)
            else:
                self.__rjecnik = dict(rjecnik)
                self.__kljucevi = sorted(self.__rjecnik.keys())

    def getAt(self, index):
        return self.__rjecnik[self.__kljucevi[index]]

    def setAt(self, index, value):
        self.__rjecnik[self.__kljucevi[index]] = value


    def __str__(self):
        return self.__keys * self.__rjecnik

    def __iter__(self):
        return iter(self.__kljucevi)

    def __repr__(self):
        parametri = []
        for key in self.__kljucevi:
            parametri.append("%r: %r" % (key, self.__rjecnik[key]))
        return parametri

    def __add__(self):
        if self.rjecnik == None:
            return self.kljucevi + 1


    def __remove__(self):
        if self.rjecnik == None:
            return self.kljucevi - 1

a = MultiSkup([1,1,2,2,2,3,3,4])
print(a)

for el in a:
print(el)
print(repr(a))

a.add(4)
print(a)
a.add(2,3)
3. Zadaci
1 of 2
print(a)
a.remove(4,2)
print(a)

