class Razlomak():
    def __init__(self, brojnik, nazivnik):
        self.brojnik = brojnik
        self.nazivnik = nazivnik
    def getBrojnik(self):
        return self.brojnik
    def setBrojnik(self, value):
        self.brojnik = value

    def getNazivnik(self):
        return self.nazivnik
    def setNazivnik(self, value):
        self.nazivnik = value

    def skrati(self):
        return self.getBrojnik() / self.getNazivnik()


r = Razlomak(5, 10)
print(r.brojnik, r.nazivnik)
print(r.skrati())


class Razlomak1():

    def __init__(self, brojnik, nazivnik):
        self._brojnik = brojnik
        self._nazivnik = nazivnik

    @property
    def brojnik(self):
        return self._brojnik

    @brojnik.setter
    def brojnik(self, value):
        self._brojnik = value

    @property
    def nazivnik(self):
        return self._nazivnik

    @nazivnik.setter
    def nazivnik(self,value):
        self._nazivnik = value

    def __repr__(self):
        return "Razlomak" + repr(self._brojnik) + repr(self._nazivnik)

    def __str__(self):
        return "Razlomak " + str(self._brojnik) + "|" + str(self._nazivnik)


r1 = Razlomak1(12,30)
r2 = Razlomak1(2,5)
r3 = Razlomak1(3,6)
print(r1,r2,repr(r3))
print(r1 == r2)
print(r3 >= r1)
print(r3 < r2)


class Razlomak2():
    def __init__(self, brojnik, nazivnik):
        self.__brojnik = brojnik
        self.__nazivnik = nazivnik


    @property
    def brojnik(self):
        return self.__brojnik

    @brojnik.setter
    def brojnik(self, value):
        self.__brojnik = value

    @property
    def nazivnik(self):
        return self.__nazivnik

    @nazivnik.setter
    def nazivnik(self,value):
        self.__nazivnik = value

    @proprety
    def razlomak(self):
        return self.__brojnik / self.__nazivnik


    def __add__(self, other):
        return Razlomak2(self.razlomak, other.razlomak)

    def __sub__(self, other):
        return Razlomak2(self.razlomak, other.razlomak)

    def __mul__(self, other):
        return Razlomak2(self.razlomak, other.razlomak)

    def __truediv__(self, other):
        return Razlomak2(self.razlomak, other.razlomak)


print(Razlomak2(3,4)+Razlomak2(5,2))
print(Razlomak2(1,3)-Razlomak2(2,6))
print(Razlomak2(2,8)*Razlomak2(4,2))
print(Razlomak2(2,3)/Razlomak2(4,5))