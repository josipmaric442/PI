import likovi
from math import pi

def opseg():
    print('funkcija "%s" modula "s%"' % (opseg.__name__, __name__))

def povrsina():
    print('funkcija "%s" modula "s%"' % (povrsina.__name__, __name__))


if __name__ == "opseg":
    print(opseg.__name__)
else:
    print(povrsina.__name__)


