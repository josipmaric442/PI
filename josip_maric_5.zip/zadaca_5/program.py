import likovi
import funkcije

def k1(self, r):
        r.self = r
        r = 3
def k2(self,a):
        a.self = a
        a = 5


print(k1, 'opsega', funkcije.opseg(k1), 'povrsine', funkcije.povrsina(k1))
print(k2, 'opsega', funkcije.opseg(k2), 'povrsine', funkcije.povrsina(k2))

