class Trokut():
    __stranice = set()
    def __init__(self, a, b, c):
        self.a = a
        self.b = b
        self.c = c
        Trokut.__stranice.add((self.a, self.b, self.c))


        if self.a < 0 or self.b < 0 or self.c < 0:
            print("Nije trokut.")
        elif self.a + self.b > self.c or self.a + self.c > self.b or self.b + self.c > self.a:
            print("Nije trokut.")
        s = (a + b + c)/2

    def __str__(self):
        if stranice == (3, 4, 5):
            return "trokut 3 4 5"

    def __repr__(self):
        if stranice == (3, 4, 5):
            return "Trokut(3, 4, 5)"

    @staticmethod
    def opseg():
        return self.a + self.b + self.c
    @staticmethod
    def povrsina():
        return Math.sqrt((s - self.a) * (s - self.b) * (s - self.c))



lista_stranica = [(1,2,3),(3,4,5),(3,4,4),(3,3,3)]
for stranice in lista_stranica:
    try:
        t = Trokut(*stranice)
        print(repr(t))
        print('%r ima opseg %.3f i povrsinu %.3f' % (t, t.opseg(), t.povrsina()))
    except Exception as e:
        print(e, stranice)



class JednakokracniTrokut(Trokut):
    def __init__(self, duljina_baze, duljina_kraka):
        self.duljina_baze = duljina_baze
        self.duljina_kraka = duljina_kraka

class JednakostranicniTrokut(JednakokracniTrokut):
    def __init__(self, stranica):
        self.stranica = stranica

trokuti = [Trokut(3,4,5),JednakokracniTrokut(3,4),JednakostranicniTrokut(5)]
for t in trokuti:
    print(t)
