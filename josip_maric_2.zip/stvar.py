class Stvar( ):
    broj_stvari = set()

    def __init__(self, stvar):
        self.stvar = stvar
        Stvar.broj_stvari.add(stvar)

    @staticmethod
    def brojStvari():
        return len(Stvar.broj_stvari) - 1

    def broj_stvari():
        return Stvar.broj_stvari.copy()



s1 = Stvar()
s2 = Stvar()
s3 = s2

print(Stvar.broj_stvari())
del(s2)
print(Stvar.broj_stvari())
del(s3)
print(Stvar.broj_stvari())
del(s1)
print(Stvar.broj_stvari())

