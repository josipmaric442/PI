class Razlomak2():
    razlomak = set()

    @staticmethod
    def stvori(self):
        return self * 100, '|', len(str(self)) * 100



r1 = Razlomak2.stvori(3.14)
print(r1)
r2 = Razlomak2.stvori(0.006021)
print(r2)
r3 = Razlomak2.stvori(-75.204)
print(r3)

